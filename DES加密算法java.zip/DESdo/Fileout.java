package com.DESdo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

public class Fileout {
	public static String getExternalName(File file)
	{
		String res = new String();
		int index = file.toString().lastIndexOf('.');
		res = file.toString().substring(index);
		return res;
	}
	public static int[] ByteToBinIntArray(byte aByte)   //8bitתΪint����
	{
		int[] res = new int[8];
		for(int i = 7 ;i>=0;i--)
		{
			res[7-i]=(int) ((aByte>>>i)&0x1);
		}
		
		return res;
	}
	public static int[] ByteArrayToBinIntArray(byte[] aByteArray)    //byte����תΪint����
	{
		int[] res = new int[aByteArray.length*8];
		for(int i = 0;i<aByteArray.length;i++)
		{
			System.arraycopy(ByteToBinIntArray(aByteArray[i]), 0, res, i*8, 8);
		}
		return res;
	}
	public static byte[] intBinArrayToByteArray(int[] aBinIntArray)
	{
		byte[] res = new byte[aBinIntArray.length/8];
		for(int i = 0 ;i<aBinIntArray.length/8;i++)
		{
			res[i] = 0;
			for(int j = 0;j<8;j++)
			{
				res[i] = (byte) (res[i]<<1);
				res[i] = (byte) (res[i]|aBinIntArray[i*8+j]);
			}
		}
		return res;
	}
	public static void fileEncrypt(File needEncryptFile,File outputPath,String akey) throws IOException
	{
		int[] key_64int = new int[64];
		int[] Data_64int = new int[64];
		int[] cipher_64int = new int[64];
		key_64int = DataAndFunction.stringToBinary(akey);
		BufferedInputStream input = new BufferedInputStream(new FileInputStream(needEncryptFile));
		BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(outputPath+"\\"+needEncryptFile.getName()+"__���ܺ�"+getExternalName(needEncryptFile)));
		byte[] cache_8byte = new byte[8];
		output.write((byte)0);
		while(input.available()>8)
		{
			input.read(cache_8byte);
			Data_64int = ByteArrayToBinIntArray(cache_8byte);
			cipher_64int = EncryptandDecrypt.encrypt(Data_64int, key_64int); 
			cache_8byte = intBinArrayToByteArray(cipher_64int);
			output.write(cache_8byte);
		}
		int addBytes = 0;
		if(input.available()>0)
		{
			addBytes = input.available();
			for(int i = 0 ;i<8;i++)
				cache_8byte[i] = 0 ;
			byte[] add = new byte[input.available()];
			input.read(add);
			System.arraycopy(add, 0, cache_8byte, 0, addBytes);
			Data_64int = ByteArrayToBinIntArray(cache_8byte);
			cipher_64int = EncryptandDecrypt.encrypt(Data_64int, key_64int);
			cache_8byte = intBinArrayToByteArray(cipher_64int);
			output.write(cache_8byte);
		}
		input.close();
		output.close();
		RandomAccessFile rafinput = new RandomAccessFile(outputPath+"\\"+needEncryptFile.getName()+"__���ܺ�"+getExternalName(needEncryptFile), "rw");
		rafinput.write((byte)addBytes);
		rafinput.close();
	}
	
	public static void fileDecrypt(File needEncryptFile,File outputPath,String akey) throws IOException
	{
		int[] key_64int = new int[64];
		int[] Data_64int = new int[64];
		int[] cipher_64int = new int[64];
		key_64int = DataAndFunction.stringToBinary(akey);
		BufferedInputStream input = new BufferedInputStream(new FileInputStream(needEncryptFile));
		BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(outputPath+"\\"+needEncryptFile.getName()+"__���ܺ�"+getExternalName(needEncryptFile)));
		byte[] cache_8byte = new byte[8];
		int addBytes = input.read();
		while(input.available()>=16)
		{
			input.read(cache_8byte);
			Data_64int = ByteArrayToBinIntArray(cache_8byte);
			cipher_64int = EncryptandDecrypt.decrypt(Data_64int, key_64int); 
			cache_8byte = intBinArrayToByteArray(cipher_64int);
			output.write(cache_8byte);
		}
		input.read(cache_8byte);
		Data_64int = ByteArrayToBinIntArray(cache_8byte);
		cipher_64int = EncryptandDecrypt.decrypt(Data_64int, key_64int); 
		cache_8byte = intBinArrayToByteArray(cipher_64int);
		for(int i = 0 ;i<addBytes;i++)
		{
			output.write(cache_8byte[i]);
		}
		
		input.close();
		output.close();
	}
}
